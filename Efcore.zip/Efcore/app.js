var express = require("express");
var bodyParser = require("body-parser");
var mongoose = require("mongoose");
var app = express();
var path = require('path');
var methodOverride = require("method-override");
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set("view engine", "ejs");
//render css files
app.use(express.static("public"));
app.use(methodOverride("_method"));

mongoose.connect("mongodb://localhost/eftracker");
var db = mongoose.connection;
 
db.on('error', console.error.bind(console, 'connection error:'));
 
db.once('open', function() {
  console.log("Connection Successful!");
});

var efsschema = new mongoose.Schema({
    title:String,
    startdate: Date,
    enddate: Date,
    task1: String,
    tc1:Number,
    task2: String,
    tc2:Number,
    task3: String,
    tc3:Number 
})

var usschema = new mongoose.Schema({
    fname:String,
    lname:String,
    email:String,
    pass:String
})

var Efforts = mongoose.model("Efforts",efsschema);
var Users = mongoose.model("Users",usschema);




//Restful


app.get("/projects",function(req,res){

    Efforts.find({},function(err, projects){
        if(err){
            console.log("Error");
        }else{
            res.render("projects",{projects:projects});
        }
    });
});

app.get("/projects/new",function(req,res){
    res.render("new");
});

app.post("/projects",function(req,res){
    Efforts.create(req.body.project, function(err,newProject){
        if(err){
            res.render("new");
        }else{
            res.redirect("/projects");
        }
    });
});

app.get("/projects/:id",function(req,res){
    Efforts.findById(req.params.id,function(err,foundpro){
        if(err){
            res.redirect("/projects");
        } else{
            res.render("show",{project: foundpro});
        }
    });
});

app.get("/projects/:id/edit",function(req,res){
    Efforts.findById(req.params.id,function(err,foundpro){
        if(err){
            res.redirect("/projects");
        } else{
            res.render("edit",{project: foundpro});
        }
    });
});

app.put("/projects/:id", function(req,res){
    Efforts.findByIdAndUpdate(req.params.id,req.body.project,function(err,updatedpro){
        if(err){
            res.redirect("/projects");
        }else{
            res.redirect("/projects/"+ req.params.id);
        }
    });
});

app.delete("/projects/:id",function(req,res){
    Efforts.findByIdAndRemove(req.params.id, function(err){
        if(err){
            res.redirect("/projects");
        }else{
            res.redirect("/projects");
        }
    });
});



//placeholders for added task
var task = ["buy socks", "practise with nodejs"];
//placeholders for removed task
var complete = ["finish jquery"];

//post route for adding new task 
app.post("/addtask", function(req, res) {
    var newTask = req.body.newtask;
    //add the new task from the post route
    task.push(newTask);
    res.redirect("/todo");
});

app.post("/removetask", function(req, res) {
    var completeTask = req.body.check;
    //check for the "typeof" the different completed task, then add into the complete task
    if (typeof completeTask === "string") {
        complete.push(completeTask);
        //check if the completed task already exits in the task when checked, then remove it
        task.splice(task.indexOf(completeTask), 1);
    } else if (typeof completeTask === "object") {
        for (var i = 0; i < completeTask.length; i++) {
            complete.push(completeTask[i]);
            task.splice(task.indexOf(completeTask[i]), 1);
        }
    }
    res.redirect("/todo");
});

//render the ejs and display added task, completed task
app.get("/todo", function(req, res) {
    res.render("todo", { task: task, complete: complete });
});
app.get("/", function(req, res) {
    res.render("Landing");
});
app.get("/taskboard",function(req,res){
    Efforts.find({},function(err, projects){
        if(err){
            console.log("Error");
        }else{
            res.render("index",{projects:projects});
        }
    });

})
app.get("/completed",function(req,res){
    Efforts.find({},function(err, projects){
        if(err){
            console.log("Error");
        }else{
            res.render("completed",{projects:projects});
        }
    });

});
app.get("/pending",function(req,res){
    Efforts.find({},function(err, projects){
        if(err){
            console.log("Error");
        }else{
            res.render("pending",{projects:projects});
        }
    });

})

app.get("/register", function(req, res) {
    res.render("register");
});

app.post("/register",function(req,res){
    Users.create(req.body.reg, function(err,newUser){
        if(err){
            res.render("register");
        }else{
            res.redirect("/login");
        }
    });
});
app.get("/login", function(req, res) {
    res.render("login");
});
app.get("/about", function(req, res) {
    res.render("about");
});


app.post("/login",function(req,res){
    
    var mail = req.body.email;
    var password = req.body.pass;
    Users.findOne({email:req.body.email},function(err,user){
    console.log(user.email);
    console.log(user.pass);
        if(mail === null){
            res.end("Login invalid");
         }else if (user.email === req.body.email && user.pass === req.body.pass){
         res.redirect("/taskboard");
        } else {
            res.end("Login invalid");
        //res.redirect("/taskboard");
       }
    })
});

//set app to listen on port 3000
app.listen(3000, function() {
    console.log("server is running on port 3000");
});
